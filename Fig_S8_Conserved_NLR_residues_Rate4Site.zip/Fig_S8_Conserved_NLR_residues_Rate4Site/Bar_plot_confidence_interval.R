data <- read.table("data_Rate4Site.txt", header = FALSE)
colnames(data) <- c("Value", "Confidence_Interval")

ci_split <- strsplit(as.character(data$Confidence_Interval), ",", fixed = TRUE)
data$CI_Lower <- as.numeric(sub("\\[", "", sapply(ci_split, `[`, 1)))
data$CI_Upper <- as.numeric(sub("\\]", "", sapply(ci_split, `[`, 2)))

data$Category <- paste("Category", seq_len(nrow(data)))
colors <- ifelse(data$Value < -1.5, "red", "gray")

pdf("Bar_Plot.pdf", width = 8, height = 6)

par(family = "Courier")
bar_positions <- barplot(
  height = data$Value,
  names.arg = data$Category,
  col = colors,
  main = "Bar Plot with Y-Axis Set to -3 to 3",
  xlab = "Categories",
  ylab = "Values",
  ylim = c(-3.5, 3.5),
  las = 2,         
  cex.names = 0.6, 
  space = 0.3,    
  width = 0.6,     
  border = NA      
)

for (i in seq_along(data$CI_Lower)) {
  if (data$CI_Lower[i] != data$CI_Upper[i]) {  
    arrows(
      x0 = bar_positions[i], 
      x1 = bar_positions[i],
      y0 = data$CI_Lower[i], 
      y1 = data$CI_Upper[i],
      angle = 90, code = 3, length = 0.03, col = "black", lwd = 0.3
    )
  }
}

dev.off()
