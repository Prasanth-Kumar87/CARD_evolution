library(ggplot2)
library(reshape2)
library(dplyr)

data <- read.csv("Counts_Vertebrates_Invertebrates.csv", row.names = 1, check.names = FALSE)

log_data <- log(data + 1)
long_data <- melt(as.matrix(log_data),
                  varnames = c("CARD_Type", "Phylum"),
                  value.name = "Log_Count")
long_data$Bubble_Size <- ifelse(long_data$Log_Count > 0, long_data$Log_Count, NA)

long_data$CARD_Type <- factor(long_data$CARD_Type, levels = rownames(data))
long_data$Phylum <- factor(long_data$Phylum, levels = colnames(data))
h_lines <- long_data %>%
  group_by(CARD_Type) %>%
  summarise(x = list(Phylum)) %>%
  tidyr::unnest(cols = x)

v_lines <- long_data %>%
  group_by(Phylum) %>%
  summarise(y = list(CARD_Type)) %>%
  tidyr::unnest(cols = y)

bubble_plot <- ggplot(long_data, aes(x = Phylum, y = CARD_Type)) +
  geom_line(data = h_lines,
            aes(x = x, y = CARD_Type, group = CARD_Type),
            color = "grey80", linewidth = 0.3) +
  geom_line(data = v_lines,
            aes(x = Phylum, y = y, group = Phylum),
            color = "grey80", linewidth = 0.3) +
  
  geom_point(aes(size = Bubble_Size, fill = CARD_Type),
             shape = 21, color = "black", stroke = 0.7, alpha = 0.9, na.rm = TRUE) +
  
  scale_size_continuous(name = "Log(Counts + 1)", range = c(2, 8)) +
  scale_fill_manual(values = scales::hue_pal()(length(unique(long_data$CARD_Type))),
                    guide = "none") +
  
  # Theme
  theme_minimal(base_size = 12) +
  theme(
    panel.background = element_rect(fill = NA, color = NA),
    plot.background = element_rect(fill = NA, color = NA),
    panel.grid = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 10),
    axis.text.y = element_text(size = 10),
    legend.position = "right"
  ) +
  labs(title = "Distribution of CARD Types Across Phyla",
       x = "Phylum", y = "CARD Type")


pdf("Bubble_plot.pdf", width = 12, height = 10, bg = "transparent")
print(bubble_plot)
dev.off()

cat("Bubble plot exported\n")
